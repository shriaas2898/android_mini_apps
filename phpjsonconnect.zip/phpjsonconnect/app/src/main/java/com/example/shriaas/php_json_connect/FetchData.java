package com.example.shriaas.php_json_connect;

import android.os.AsyncTask;

import com.example.shriaas.php_json_connect.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by shriaas on 21/2/19.
 */

public class FetchData extends AsyncTask<String,Void,String> {
    MainActivity activity;
    URL url;
    HttpURLConnection htpc;
    public FetchData(MainActivity mainActivity) {
        activity =mainActivity;
    }


    @Override
    protected String doInBackground(String... params) {
        String ln=null;
        try {
            url = new URL(params[0]);
            htpc =(HttpURLConnection) url.openConnection();
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(htpc.getInputStream())
            );
            StringBuffer sb = new StringBuffer(20);

            while((ln=br.readLine())!=null){
                sb.append(ln);

            }
            br.close();
            ln = sb.toString();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ln;
    }
    public void onPostExecute(String result)
    {
        StringBuffer ssb = new StringBuffer("");
        try{
            JSONArray jsr = new JSONArray(result);
            for (int i=0;i<jsr.length();i++)
            {
                JSONObject job = jsr.getJSONObject(i);
                ssb.append(job.getString("name"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        activity.tv.setText(ssb.toString());

    }
}
